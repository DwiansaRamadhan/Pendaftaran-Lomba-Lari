document.getElementById('login').addEventListener('click', function() {
    document.querySelector('.button-container').classList.add('hidden');
    document.getElementById('form-login').classList.remove('hidden');
    document.getElementById('form-daftar').classList.add('hidden');
});

document.getElementById('daftar').addEventListener('click', function() {
    document.querySelector('.button-container').classList.add('hidden');
    document.getElementById('form-daftar').classList.remove('hidden');
    document.getElementById('form-login').classList.add('hidden');
});

document.getElementById('form-marathon').addEventListener('submit', function(event) {
    event.preventDefault();

    const nama = document.getElementById('nama').value;
    const username = document.getElementById('username').value;
    const email = document.getElementById('email').value;
    const telepon = document.getElementById('telepon').value;
    const password = document.getElementById('password').value;
    const ulangiPassword = document.getElementById('ulangi-password').value;
    const jenisKelamin = document.querySelector('input[name="jenis-kelamin"]:checked').value;

    if (password !== ulangiPassword) {
        alert('Password dan Ulangi Password harus sama');
        return;
    }

    if (nama && username && email && telepon && password && ulangiPassword && jenisKelamin) {
        alert(`Terima kasih, ${nama}! Anda telah berhasil mendaftar.`);
    } else {
        alert('Harap isi semua field yang diperlukan.');
    }
});

document.getElementById('form-login').addEventListener('submit', function(event) {
    event.preventDefault();

    const username = document.getElementById('login-username').value;
    const password = document.getElementById('login-password').value;

    if (username && password) {
        alert(`Selamat datang, ${username}! Anda berhasil login.`);
    } else {
        alert('Harap isi semua field yang diperlukan.');
    }
});
